﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Switch_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string p = textBox1.Text;
          int pr = int.Parse(p);

            switch (pr)
            {
                case 0:
                    {
                        textBox2.Text = "0 points";
                        break;
                    }
                case 1:                                                                                                                                  
                    {
                        textBox2.Text = "5 points";
                        break;
                    }
                case 2:
                    {
                        textBox2.Text = "15 points";
                        break;
                    }
                case 3:
                    {
                        textBox2.Text = "30 points";
                        break;
                    }
                case 4:
                    {
                        textBox2.Text = "60 points";
                        break;
                    }
                default:
                    textBox2.Text = "Enter no. between 0-4 only";
                    break;
            }
        }
    }
}
