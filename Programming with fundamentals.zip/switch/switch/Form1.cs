﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace @switch
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string day = textBox1.Text;
           int d = int.Parse(day);

            switch (d)
            {
                case 1:
                    {
                        MessageBox.Show("Monday");
                        break;
                    }
                case 2:
                    {
                        MessageBox.Show("Tuesday");
                        break;
                    }
                case 3:
                    {
                        MessageBox.Show("Wednesday");
                        break;
                    }
                case 4:
                    {
                        MessageBox.Show("Thursday");
                        break;
                    }
                case 5:
                    {
                        MessageBox.Show("Friday");
                        break;
                    }
                case 6:
                    {
                        MessageBox.Show("Saturday");
                        break;
                    }
             
                default:
                    MessageBox.Show("Holiday");
                    break;
            }
        }

        }
    }

