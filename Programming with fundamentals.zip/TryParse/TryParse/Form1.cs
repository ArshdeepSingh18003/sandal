﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TryParse
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double m1, m2;
            if(double.TryParse(textBox1.Text,out m1))
            {
                if(double.TryParse(textBox2.Text,out m2))
                {
                    MessageBox.Show((m1 + m2).ToString());
                }
                else
                {
                    MessageBox.Show("Enter integers only");
                }
            }
            else
            {
                MessageBox.Show("Enter integers only");
            }
        }
    }
}
